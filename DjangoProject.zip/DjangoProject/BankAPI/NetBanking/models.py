from django.db import models


# Create your models here.

class OnlinePay(models.Model):
    user_name = models.CharField(max_length=45)
    pass_word = models.CharField(max_length=45)
    account_number = models.IntegerField()
    creditcard_number = models.IntegerField()
    pay_amount = models.IntegerField()
    due_amount = models.IntegerField()
    total_amount = models.IntegerField()
