from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import OnlinePay
from .serializers import OnlinePaySer

# Create your views here.

class Pay(APIView):
    def get(self, r):
        pay_details = OnlinePay.objects.all()
        serobj = OnlinePaySer(pay_details, many=True)
        return Response(serobj.data)

    def post(self,r):
        serobj = OnlinePaySer(data=r.data)
        if serobj.is_valid():
            serobj.save()
            return Response(serobj.data,status=status.HTTP_201_CREATED)
        return Response(serobj.errors,status=status.HTTP_404_NOT_FOUND)


class PayUpdateDelete(APIView):
    def put(self,r,pk):
        payobj = OnlinePay.objects.get(pk=pk)
        serobj = OnlinePaySer(payobj,data=r.data)
        if serobj.is_valid():
            serobj.save()
            return Response(serobj.data, status=status.HTTP_201_CREATED)
        return Response(serobj.errors, status=status.HTTP_404_NOT_FOUND)

    def delete(self,r,pk):
        payobj = OnlinePay.objects.get(pk=pk)
        payobj.delete()
        return Response(status = status.HTTP_204_NO_CONTENT)


