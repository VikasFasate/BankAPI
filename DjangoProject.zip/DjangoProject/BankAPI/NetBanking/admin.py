from django.contrib import admin
from .models import OnlinePay

# Register your models here.

class OnlinePayAdmin(admin.ModelAdmin):
    list_display = ['user_name', 'pass_word', 'account_number', 'creditcard_number',
                    'pay_amount', 'due_amount', 'total_amount']


admin.site.register(OnlinePay, OnlinePayAdmin)