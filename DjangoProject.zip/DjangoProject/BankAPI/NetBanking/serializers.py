from rest_framework import serializers
from .models import OnlinePay

class OnlinePaySer(serializers.ModelSerializer):
    class Meta:
        model = OnlinePay
        fields = "__all__"

        